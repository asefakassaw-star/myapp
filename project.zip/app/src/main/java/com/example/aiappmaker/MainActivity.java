package com.example.aiappmaker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText serverInput, promptInput;
    private Button buildBtn;
    private TextView statusText;
    private ProgressBar progress;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private File pendingApk = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverInput = findViewById(R.id.serverInput);
        promptInput = findViewById(R.id.promptInput);
        buildBtn = findViewById(R.id.buildBtn);
        statusText = findViewById(R.id.statusText);
        progress = findViewById(R.id.progress);

        SharedPreferences prefs = getSharedPreferences("aiappmaker", MODE_PRIVATE);
        serverInput.setText(prefs.getString("server", ""));

        buildBtn.setOnClickListener(v -> startBuild());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Back from the "allow installs" settings screen
        if (pendingApk != null && canInstall()) {
            File f = pendingApk;
            pendingApk = null;
            tryInstall(f);
        }
    }

    private boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    private void startBuild() {
        String server = serverInput.getText().toString().trim();
        String prompt = promptInput.getText().toString().trim();
        if (server.endsWith("/")) server = server.substring(0, server.length() - 1);
        if (server.isEmpty() || prompt.isEmpty()) {
            Toast.makeText(this, "Enter the server URL and describe your app", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences("aiappmaker", MODE_PRIVATE).edit().putString("server", server).apply();
        setBusy(true);
        setStatus("Sending your idea...");

        final String s = server;
        io.execute(() -> {
            try {
                String id = postBuild(s, prompt);
                pollUntilDone(s, id);
            } catch (Exception e) {
                ui.post(() -> {
                    setStatus("Error: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    // ---- Server calls -------------------------------------------------

    private String postBuild(String server, String prompt) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(server + "/build").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject();
        body.put("prompt", prompt);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        String resp = readResponse(c);
        return new JSONObject(resp).getString("id");
    }

    private void pollUntilDone(String server, String id) throws Exception {
        for (int i = 0; i < 300; i++) { // about 15 minutes
            HttpURLConnection c = (HttpURLConnection) new URL(server + "/status/" + id).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            JSONObject j = new JSONObject(readResponse(c));
            String status = j.optString("status", "");
            String message = j.optString("message", status);

            if (status.equals("done")) {
                ui.post(() -> setStatus("Downloading your APK..."));
                File apk = download(server, id);
                ui.post(() -> {
                    setBusy(false);
                    setStatus("Your app is ready.");
                    tryInstall(apk);
                });
                return;
            }
            if (status.equals("failed")) {
                throw new Exception(message);
            }
            ui.post(() -> setStatus(message));
            Thread.sleep(3000);
        }
        throw new Exception("Timed out waiting for the build");
    }

    private File download(String server, String id) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(server + "/apk/" + id).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(120000);
        if (c.getResponseCode() >= 400) throw new Exception("Download failed (" + c.getResponseCode() + ")");
        File dir = new File(getCacheDir(), "apks");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, "app-" + id + ".apk");
        try (InputStream in = c.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        }
        return out;
    }

    private String readResponse(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        }
        String text = bos.toString("UTF-8");
        if (code >= 400) throw new Exception("Server error " + code + ": " + text);
        return text;
    }

    // ---- Install ------------------------------------------------------

    private void tryInstall(File apk) {
        if (!canInstall()) {
            pendingApk = apk;
            Toast.makeText(this, "Allow installs from this app, then come back", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apk);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    // ---- UI helpers ---------------------------------------------------

    private void setStatus(String s) {
        statusText.setText(s);
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }
}
